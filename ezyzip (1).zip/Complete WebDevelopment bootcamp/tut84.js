// Within computer programming, the acronym CRUD stands for create, read, update and delete. 
show dbs 
use harryKart
show collections

db.items.find()
db.items.updateOne({name: "Moto 30s"}, {$set: {price: 2}})
db.items.find()
db.items.updateMany({name: "Moto 30s"}, {$set: {price: 3, rating: 1}})

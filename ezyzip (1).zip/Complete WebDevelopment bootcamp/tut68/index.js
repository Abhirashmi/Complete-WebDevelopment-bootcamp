// console.log(average([3,4]))
// const average = require("./mod");
const mod = require("./mod");
console.log(mod.name) 
// console.log(mod.avg([3,4]))
console.log("This is index.js");


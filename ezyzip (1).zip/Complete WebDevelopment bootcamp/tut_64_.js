const fs = require("fs");
let text = fs.readFileSync("abhi.txt", "utf-8");
text = text.replace("hey", "heyyyyyyyyyyyyyyy");

console.log("The content of the file is")
console.log(text);

console.log("Creating a new file...")
fs.writeFileSync("abhi1.txt", text);
